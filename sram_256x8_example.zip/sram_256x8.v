// ============================================================================
// sram_256x8 — 256-byte SRAM wrapper for sram22_256x8m8w1 hard macro
// ============================================================================
//
// Wraps sram22_256x8m8w1 (8-bit × 256 entries, single-port 1RW).
//
// Three instances needed for the 65C02 MMU:
//   1. jbank_sram      — JBANK stack         (init: all zeros)
//   2. zbank_sram      — ZBANK lookup        (init: identity, mem[i]=i)
//   3. access_key_sram — protection keys     (init: all zeros)
//
// SRAM timing (synchronous reads — 1-cycle latency):
//   posedge clk: inputs (addr, wdata, we) are registered
//   negedge clk: write occurs (if we=1)
//   after posedge: rdata updates combinationally (from registered address)
//
// Single port: addr0/wdata0/we0/rdata0.  The CPU defaults addr0 to AB[7:0]
// when not performing a state-machine operation, providing zero-latency
// BANK_REG_MEM reads on idle cycles.  Port conflicts (state-machine
// operation in flight while BANK_REG_MEM also needs the SRAM) are handled
// by brm_stall logic in the CPU.
//
// Parameter INIT_IDENTITY: simulation-only. 1=identity map, 0=all zeros.
// ============================================================================

`ifdef SIM
// ============================================================
// Behavioral model for simulation (Icarus Verilog, etc.)
// Matches hard macro timing: synchronous address registration with
// combinational read output. Write on negedge.
//
// Timeline per cycle:
//   posedge: addr0_reg captures input address
//   after posedge: rdata0 updates combinationally (mem[addr0_reg])
//   negedge: CPU reads rdata0 (stable); write executes if we0_reg
//   next posedge: new address captured
// ============================================================
module sram_256x8 (
    input        clk,
    input  [7:0] addr0,
    input  [7:0] wdata0,
    output [7:0] rdata0,
    input        we0
);

parameter INIT_IDENTITY = 0;

reg [7:0] mem [0:255];

// Registered inputs (match hard macro behavior)
reg [7:0] addr0_reg;
reg [7:0] wdata0_reg;
reg       we0_reg;

// Register inputs on posedge
always @(posedge clk) begin
    addr0_reg  <= addr0;
    wdata0_reg <= wdata0;
    we0_reg    <= we0;
end

// Write on negedge (using registered values from previous posedge)
always @(negedge clk) begin
    if (we0_reg)
        mem[addr0_reg] <= wdata0_reg;
end

// Combinational read output from registered address
// After posedge: addr0_reg updates, rdata0 follows combinationally
// Stable well before negedge when CPU samples it
assign rdata0 = mem[addr0_reg];

// Simulation-only initialization
integer i;
initial begin
    addr0_reg  = 8'h00;
    wdata0_reg = 8'h00;
    we0_reg    = 1'b0;
    for (i = 0; i < 256; i = i + 1)
        mem[i] = INIT_IDENTITY ? i[7:0] : 8'h00;
end

endmodule

`else
// ============================================================
// Synthesis wrapper around sram22_256x8m8w1
// ============================================================
module sram_256x8 (
`ifdef USE_POWER_PINS
    inout        vccd1,
    inout        vssd1,
`endif
    input        clk,
    input  [7:0] addr0,
    input  [7:0] wdata0,
    output [7:0] rdata0,
    input        we0
);

parameter INIT_IDENTITY = 0;  // Ignored for synthesis (must be handled by reset logic)

sram22_256x8m8w1 u_sram (
`ifdef USE_POWER_PINS
    .vccd1 (vccd1),
    .vssd1 (vssd1),
`endif
    .clk0  (clk),
    .csb0  (1'b0),             // Always selected
    .web0  (~we0),             // Active-low write enable
    .wmask0(1'b1),             // Write full byte
    .addr0 (addr0),            // 8-bit address (256 entries)
    .din0  (wdata0),
    .dout0 (rdata0)
);

endmodule
`endif
